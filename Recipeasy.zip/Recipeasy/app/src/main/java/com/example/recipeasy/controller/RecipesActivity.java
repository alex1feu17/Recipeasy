package com.example.recipeasy.controller;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.recipeasy.R;
import com.example.recipeasy.model.Recipe;
import com.example.recipeasy.model.RecipesService;
import com.example.recipeasy.model.User;
import com.example.recipeasy.model.UserService;

import java.util.ArrayList;
import java.util.Random;

public class RecipesActivity extends AppCompatActivity {
    private final static int ADD_RECIPE_REQUEST=1;
    private final static int EDIT_RECIPE_REQUEST=2;
    public final static String KEY_EDIT_RECIPE_EXTRA="com.example.edit-recipe-extra";
    private com.example.recipeasy.databinding.ActivityRecipesBinding binding;
    private RepicesAdapter recipesAdapter;

    private int getCurrentUserId() {
        return UserService.getInstance().getCurrentUser().getId();
    }

    private ArrayList<Recipe> getUserRecipes()
    {
        return RecipesService.getInstance().getAll(getCurrentUserId());
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding= com.example.recipeasy.databinding.ActivityRecipesBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.recyclerRecipes.setHasFixedSize(true);
        binding.recyclerRecipes.addItemDecoration(new DividerItemDecoration(this,DividerItemDecoration.VERTICAL));
        binding.recyclerRecipes.setLayoutManager(new LinearLayoutManager(this));

        recipesAdapter=new RepicesAdapter();

        binding.recyclerRecipes.setAdapter(recipesAdapter);

        binding.fabAdd.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Intent addRecipeIntent= new Intent(RecipesActivity.this,RecipeActivity.class);
                startActivityForResult(addRecipeIntent,ADD_RECIPE_REQUEST);
                startActivity(addRecipeIntent);
            }
        });
        /*
        binding.buttonEdit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view)
            {
                ArrayList<Recipe> recipes=RecipesService.getInstance().getAll(getCurrentUserId());

                int recipesCount=recipes.size();

                if(recipesCount>0)
                {
                    Random random=new Random();
                    Recipe recipe=recipes.get(random.nextInt(recipesCount));

                    Intent editRecipeIntent=new Intent(RecipesActivity.this,RecipeActivity.class);
                    editRecipeIntent.putExtra(KEY_EDIT_RECIPE_EXTRA,recipe);
                    startActivityForResult(editRecipeIntent,EDIT_RECIPE_REQUEST);
                }else
                {
                    Toast.makeText(RecipesActivity.this, "No recipe!", Toast.LENGTH_SHORT).show();
                }
            }
        });

         */

        binding.buttonLogOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserService.getInstance().logOut();

                Intent logoutIntent=new Intent(RecipesActivity.this,LoginActivity.class);
                startActivity(logoutIntent);
                finish();
            }
        });

    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode==RESULT_OK&&requestCode==ADD_RECIPE_REQUEST|| requestCode==EDIT_RECIPE_REQUEST)
        {

        }
    }

}